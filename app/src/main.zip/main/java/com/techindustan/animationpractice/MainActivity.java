package com.techindustan.animationpractice;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.bubble1)
    ImageView bubble1;
    @BindView(R.id.bubble2)
    ImageView bubble2;
    @BindView(R.id.circleA1)
    ImageView circleA1;
    @BindView(R.id.circleA2)
    ImageView circleA2;
    @BindView(R.id.circleA3)
    ImageView circleA3;
    @BindView(R.id.circleA4)
    ImageView circleA4;
    @BindView(R.id.circleB1)
    ImageView circleB1;
    @BindView(R.id.circleB2)
    ImageView circleB2;
    @BindView(R.id.circleB3)
    ImageView circleB3;
    @BindView(R.id.circleB4)
    ImageView circleB4;
    @BindView(R.id.animate)
    Button animate;
    int WIDTH = 0;
    int HEIGHT = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        HEIGHT = displayMetrics.heightPixels;
        WIDTH = displayMetrics.widthPixels;
        bubble2.setVisibility(View.GONE);
        bubble1.setVisibility(View.GONE);

    }

    @OnClick(R.id.animate)
    public void onViewClicked() {

        /*final Animation img1TransAnim = AnimationUtils.loadAnimation(this, R.anim.translationset);
        Animation img2TransAnim = AnimationUtils.loadAnimation(this, R.anim.translationset);
        bubble2.startAnimation(img1TransAnim);
        img1TransAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                bubble1.setAnimation(img1TransAnim);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });*/



       /* Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
        fadeIn.setDuration(1000);

        ObjectAnimator objectAnimatorX
                = ObjectAnimator.ofFloat(bubble2, "translationX", 0f, 500f);
        ObjectAnimator objectAnimatorY
                = ObjectAnimator.ofFloat(bubble2, "translationY", 200f, 0f);
        //objectAnimatorX.setDuration(200);
        objectAnimatorY.setDuration(1000);


        //objectAnimatorX.start();
        objectAnimatorY.start();
        objectAnimatorY.setTarget(fadeIn);*/
        animateViews();
    }

    void animate() {
        //Toast.makeText(this, "click", Toast.LENGTH_SHORT).show();
        Animation animTranslate = new TranslateAnimation(0, 0, 1000, 0);
        animTranslate.setDuration(3000);
        animTranslate.setFillAfter(true);

        ObjectAnimator objectAnimatorY
                = ObjectAnimator.ofFloat(bubble2, "translationY", 500f, 0f);
        //objectAnimatorY.setInterpolator(new DecelerateInterpolator());
        objectAnimatorY.setDuration(1000);
        ObjectAnimator alphaAnimation = ObjectAnimator.ofFloat(bubble2, View.ALPHA, 0, 1);
        alphaAnimation.setDuration(1500);


        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
        fadeIn.setDuration(3000);

        Animation fade = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fadin);

        AnimationSet animSet = new AnimationSet(false); //change to false
        animSet.addAnimation(fade);
        animSet.addAnimation(animTranslate);
        //animSet.setRepeatMode(Animation.INFINITE);
        bubble1.setAnimation(fade);
        objectAnimatorY.start();
        alphaAnimation.start();

    }

    void animateViews() {

        ObjectAnimator fadeOut2 = ObjectAnimator.ofFloat(bubble2, "alpha", 1f);
        fadeOut2.setDuration(500);

        ObjectAnimator fadeOut1 = ObjectAnimator.ofFloat(bubble1, "alpha", 1f);
        fadeOut1.setDuration(500);


        ObjectAnimator objectAnimatorY2
                = ObjectAnimator.ofFloat(bubble2, "translationY", 500f, 0f);
        objectAnimatorY2.setDuration(500);


        final ObjectAnimator fade2 = ObjectAnimator.ofFloat(bubble2, "alpha", 0f);
        fade2.setDuration(1000);

        ObjectAnimator objectAnimatorY1
                = ObjectAnimator.ofFloat(bubble1, "translationY", 500f, 0f);
        objectAnimatorY1.setDuration(500);


        final ObjectAnimator fade1 = ObjectAnimator.ofFloat(bubble1, "alpha", 0f);
        fade1.setDuration(1000);


        ObjectAnimator om1 = ObjectAnimator.ofFloat(circleA1, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator om2 = ObjectAnimator.ofFloat(circleA2, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator om3 = ObjectAnimator.ofFloat(circleA3, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator om4 = ObjectAnimator.ofFloat(circleA4, "alpha", 1f);
        om1.setDuration(300);

        ObjectAnimator omB1 = ObjectAnimator.ofFloat(circleB1, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator omB2 = ObjectAnimator.ofFloat(circleB2, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator omB3 = ObjectAnimator.ofFloat(circleB3, "alpha", 1f);
        om1.setDuration(300);
        ObjectAnimator omB4 = ObjectAnimator.ofFloat(circleB4, "alpha", 1f);
        om1.setDuration(300);

/*
        ObjectAnimator scaleYAnimator = ObjectAnimator.ofFloat(zoomTarget, "scaleY", 0.5f);
        scaleYAnimator.setRepeatMode(ValueAnimator.REVERSE);
        scaleYAnimator.setRepeatCount(1);
        scaleYAnimator.setDuration(1000);

        ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(zoomTarget, "rotation", 0f, 360f);
        rotationAnimator.setRepeatMode(ValueAnimator.RESTART);
        rotationAnimator.setRepeatCount(1);
        rotationAnimator.setDuration(1000);*/

//sequencial animation
        final AnimatorSet set = new AnimatorSet();
       /* set.play(objectAnimatorY2).after(objectAnimatorY1);//.with(fadeOut1).with(fadeOut2).after(fade1).after(fade2);
        set.play(fade1).with(fade2);*/
        List<Animator> anims = new ArrayList<>();
        anims.add(objectAnimatorY2);
        anims.add(om1);
        anims.add(om2);
        anims.add(om3);
        anims.add(om4);
        anims.add(objectAnimatorY1);
        anims.add(omB1);
        anims.add(omB2);
        anims.add(omB3);
        anims.add(omB4);
        set.playSequentially(anims);

        List<Animator> anims2 = new ArrayList<>();
        anims2.add(fade2);
        anims2.add(fade1);
        //set.playTogether(anims2);
        set.start();
        bubble2.setVisibility(View.VISIBLE);
        bubble1.setVisibility(View.VISIBLE);


        set.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);


            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                // fade1.start();
                // fade2.start();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        set.start();
                        bubble2.setVisibility(View.VISIBLE);
                        bubble1.setVisibility(View.VISIBLE);
                    }
                }, 2000);
            }
        });

    }


}
